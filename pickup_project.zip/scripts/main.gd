extends Node3D

var car: VehicleBody3D
var wheels: Array[VehicleWheel3D] = []
var camera: Camera3D
var left_down := false
var right_down := false
var gas_down := false
var reverse_down := false
var handbrake_down := false
var steer_value := 0.0
var cam_yaw := 0.0
var cam_pitch := 0.30
var cam_distance := 8.2
var touch_points := {}
var last_pinch := 0.0
var speed_label: Label
var station_label: Label
var station_index := 0
var stations := [
    {"name":"СВОБОДНАЯ ПЛОЩАДКА", "pos":Vector3(0,1.15,4)},
    {"name":"ДИАГОНАЛЬНЫЙ ВЫВЕС", "pos":Vector3(0,1.15,-22)},
    {"name":"СТИРАЛЬНАЯ ДОСКА", "pos":Vector3(0,1.15,-52)},
    {"name":"РАЗНОХОД КОЛЁС", "pos":Vector3(0,1.15,-82)},
    {"name":"БОКОВОЙ УКЛОН", "pos":Vector3(0,1.35,-112)},
    {"name":"РАМПА", "pos":Vector3(0,1.15,-142)},
    {"name":"СТУПЕНИ", "pos":Vector3(0,1.15,-170)},
    {"name":"КОЛЛИЗИЯ", "pos":Vector3(0,1.15,-198)}
]

func _ready() -> void:
    _build_world()
    _build_course()
    _build_car()
    _build_camera()
    _build_ui()
    _reset_car()

func _build_world() -> void:
    var we := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sm := ProceduralSkyMaterial.new()
    sm.sky_top_color = Color(0.08,0.20,0.34)
    sm.sky_horizon_color = Color(0.55,0.73,0.86)
    sm.ground_horizon_color = Color(0.35,0.39,0.35)
    sm.ground_bottom_color = Color(0.07,0.08,0.07)
    sky.sky_material = sm
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.55
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    we.environment = env
    add_child(we)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50,-28,0)
    sun.light_energy = 1.35
    sun.light_color = Color(1.0,0.94,0.84)
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 90.0
    add_child(sun)

func _build_course() -> void:
    _box("Ground", Vector3(0,-0.3,-100), Vector3(42,0.6,250), Vector3.ZERO, Color(0.30,0.36,0.31))
    _box("DiagL1", Vector3(-0.9,0.16,-30), Vector3(0.95,0.32,2.6), Vector3.ZERO, Color(0.45,0.28,0.17))
    _box("DiagR1", Vector3(0.9,0.25,-33), Vector3(0.95,0.50,2.6), Vector3.ZERO, Color(0.45,0.28,0.17))
    _box("DiagL2", Vector3(-0.9,0.30,-36), Vector3(0.95,0.60,2.6), Vector3.ZERO, Color(0.45,0.28,0.17))
    _box("DiagR2", Vector3(0.9,0.18,-39), Vector3(0.95,0.36,2.6), Vector3.ZERO, Color(0.45,0.28,0.17))
    for i in range(14):
        var h := 0.10 + 0.045 * sin(float(i) * 1.6)
        _box("Wash%d"%i, Vector3(0,h*0.5,-59-i*1.15), Vector3(5.0,h,0.38), Vector3.ZERO, Color(0.40,0.40,0.37))
    for i in range(7):
        var side := -1.0 if i%2==0 else 1.0
        var h := 0.25 + 0.10 * float(i%3)
        _box("Travel%d"%i, Vector3(side*0.92,h*0.5,-90-i*2.2), Vector3(0.95,h,1.55), Vector3.ZERO, Color(0.36,0.29,0.23))
    _box("SideSlope", Vector3(0,1.05,-121), Vector3(8,0.45,18), Vector3(0,0,13), Color(0.31,0.35,0.37))
    _box("RampUp", Vector3(0,0.85,-151), Vector3(5.8,0.45,10), Vector3(9.5,0,0), Color(0.37,0.38,0.41))
    _box("RampTop", Vector3(0,1.68,-158), Vector3(5.8,0.45,5), Vector3.ZERO, Color(0.37,0.38,0.41))
    _box("RampDown", Vector3(0,0.85,-165), Vector3(5.8,0.45,10), Vector3(-9.5,0,0), Color(0.37,0.38,0.41))
    for i in range(7):
        var h := 0.14 + 0.10*float(i)
        _box("Step%d"%i, Vector3(0,h*0.5,-178-i*1.28), Vector3(4.3,h,1.22), Vector3.ZERO, Color(0.38,0.38,0.41))
    _box("Wall", Vector3(0,1.1,-210), Vector3(7.0,2.2,0.75), Vector3.ZERO, Color(0.50,0.14,0.12))

func _box(n:String, p:Vector3, s:Vector3, r:Vector3, c:Color) -> void:
    var b := StaticBody3D.new()
    b.name=n; b.position=p; b.rotation_degrees=r
    var cs := CollisionShape3D.new(); var sh := BoxShape3D.new(); sh.size=s; cs.shape=sh; b.add_child(cs)
    var mi := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size=s
    var mat := StandardMaterial3D.new(); mat.albedo_color=c; mat.roughness=0.86; bm.material=mat
    mi.mesh=bm; mi.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_ON; b.add_child(mi)
    var pm := PhysicsMaterial.new(); pm.friction=1.0; pm.bounce=0.0; b.physics_material_override=pm
    add_child(b)

func _build_car() -> void:
    car = VehicleBody3D.new()
    car.name="Pickup"
    car.mass=2300.0
    car.continuous_cd=true
    car.can_sleep=false
    car.linear_damp=0.04
    car.angular_damp=0.18
    add_child(car)
    var body_shape := CollisionShape3D.new(); var bs := BoxShape3D.new(); bs.size=Vector3(1.95,0.72,4.85)
    body_shape.shape=bs; body_shape.position=Vector3(0,0.92,0.0); car.add_child(body_shape)
    _car_box(Vector3(1.95,0.48,4.85), Vector3(0,0.86,0), Color(0.28,0.34,0.22))
    _car_box(Vector3(1.84,0.82,1.70), Vector3(0,1.48,-0.65), Color(0.28,0.34,0.22))
    _car_box(Vector3(1.76,0.54,1.45), Vector3(0,1.55,-0.62), Color(0.035,0.07,0.09))
    _car_box(Vector3(1.82,0.16,1.85), Vector3(0,1.12,1.55), Color(0.06,0.07,0.06))
    _car_box(Vector3(0.10,0.44,1.90), Vector3(-0.88,1.28,1.55), Color(0.28,0.34,0.22))
    _car_box(Vector3(0.10,0.44,1.90), Vector3(0.88,1.28,1.55), Color(0.28,0.34,0.22))
    _car_box(Vector3(2.02,0.22,0.36), Vector3(0,0.78,-2.56), Color(0.035,0.04,0.045))
    _car_box(Vector3(1.98,0.20,0.34), Vector3(0,0.74,2.56), Color(0.035,0.04,0.045))
    _wheel(Vector3(-0.88,0.58,-1.65), true, false)
    _wheel(Vector3(0.88,0.58,-1.65), true, false)
    _wheel(Vector3(-0.88,0.58,1.55), false, true)
    _wheel(Vector3(0.88,0.58,1.55), false, true)

func _car_box(s:Vector3,p:Vector3,c:Color) -> void:
    var mi:=MeshInstance3D.new(); var bm:=BoxMesh.new(); bm.size=s
    var m:=StandardMaterial3D.new(); m.albedo_color=c; m.metallic=0.14; m.roughness=0.50; bm.material=m
    mi.mesh=bm; mi.position=p; mi.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_ON; car.add_child(mi)

func _wheel(p:Vector3, steering_wheel:bool, traction:bool) -> void:
    var w:=VehicleWheel3D.new(); w.position=p
    w.use_as_steering=steering_wheel; w.use_as_traction=traction
    w.wheel_radius=0.46; w.wheel_rest_length=0.48; w.suspension_travel=0.28
    w.suspension_stiffness=28.0; w.suspension_max_force=7200.0
    w.damping_compression=0.36; w.damping_relaxation=0.58
    w.wheel_friction_slip=1.25 if steering_wheel else 1.18
    w.wheel_roll_influence=0.07
    var mi:=MeshInstance3D.new(); var cyl:=CylinderMesh.new(); cyl.top_radius=0.46; cyl.bottom_radius=0.46; cyl.height=0.34; cyl.radial_segments=24
    var mat:=StandardMaterial3D.new(); mat.albedo_color=Color(0.025,0.028,0.03); mat.roughness=0.78; cyl.material=mat
    mi.mesh=cyl; mi.rotation_degrees.z=90.0; mi.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_ON
    w.add_child(mi); car.add_child(w); wheels.append(w)

func _build_camera() -> void:
    camera=Camera3D.new(); camera.current=true; camera.fov=67.0; add_child(camera)

func _build_ui() -> void:
    var layer:=CanvasLayer.new(); add_child(layer)
    speed_label=Label.new(); speed_label.position=Vector2(34,28); speed_label.add_theme_font_size_override("font_size",30); layer.add_child(speed_label)
    station_label=Label.new(); station_label.position=Vector2(710,28); station_label.size=Vector2(500,50); station_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; station_label.add_theme_font_size_override("font_size",24); layer.add_child(station_label)
    _touch(layer,"left",Vector2(70,870),Vector2(130,130),"◀")
    _touch(layer,"right",Vector2(225,870),Vector2(130,130),"▶")
    _touch(layer,"reverse",Vector2(1565,870),Vector2(130,130),"▼\nНАЗАД")
    _touch(layer,"gas",Vector2(1720,870),Vector2(130,130),"▲\nГАЗ")
    _touch(layer,"handbrake",Vector2(870,900),Vector2(180,90),"РУЧНИК")
    var reset:=Button.new(); reset.text="RESET"; reset.position=Vector2(810,820); reset.size=Vector2(140,62); reset.pressed.connect(_reset_car); layer.add_child(reset)
    var test:=Button.new(); test.text="TEST"; test.position=Vector2(970,820); test.size=Vector2(140,62); test.pressed.connect(_next_station); layer.add_child(test)

func _touch(layer:CanvasLayer,key:String,p:Vector2,s:Vector2,text:String) -> void:
    var panel:=Panel.new(); panel.position=p; panel.size=s; layer.add_child(panel)
    var lab:=Label.new(); lab.text=text; lab.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); lab.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; lab.vertical_alignment=VERTICAL_ALIGNMENT_CENTER; lab.add_theme_font_size_override("font_size",22); panel.add_child(lab)
    var t:=TouchScreenButton.new(); t.position=p+s*0.5; var shape:=RectangleShape2D.new(); shape.size=s; t.shape=shape; t.shape_centered=true; t.shape_visible=false; layer.add_child(t)
    if key=="left": t.pressed.connect(func(): left_down=true); t.released.connect(func(): left_down=false)
    elif key=="right": t.pressed.connect(func(): right_down=true); t.released.connect(func(): right_down=false)
    elif key=="gas": t.pressed.connect(func(): gas_down=true); t.released.connect(func(): gas_down=false)
    elif key=="reverse": t.pressed.connect(func(): reverse_down=true); t.released.connect(func(): reverse_down=false)
    elif key=="handbrake": t.pressed.connect(func(): handbrake_down=true); t.released.connect(func(): handbrake_down=false)

func _physics_process(delta:float) -> void:
    if car==null: return
    var fwd := -car.global_transform.basis.z.normalized()
    var signed_speed := car.linear_velocity.dot(fwd)
    var kmh := abs(signed_speed)*3.6
    var steer_target:=0.0
    # Godot VehicleBody3D uses MODEL_FRONT (-Z). Positive steering/yaw turns -Z toward -X = LEFT.
    if left_down and not right_down: steer_target=1.0
    elif right_down and not left_down: steer_target=-1.0
    var max_deg:=lerp(31.0,12.0,clamp(kmh/100.0,0.0,1.0))
    steer_value=move_toward(steer_value,steer_target,3.5*delta)
    car.steering=steer_value*deg_to_rad(max_deg)
    var force:=0.0
    var service_brake:=0.0
    if gas_down and not reverse_down:
        if signed_speed < -0.8: service_brake=62.0
        else: force=105.0*(1.0-clamp(kmh/145.0,0.0,0.72))
    elif reverse_down and not gas_down:
        if signed_speed > 0.8: service_brake=62.0
        elif signed_speed > -8.0: force=-68.0
    car.engine_force=force
    car.brake=service_brake
    for i in range(wheels.size()): wheels[i].brake = 95.0 if handbrake_down and i>=2 else 0.0
    speed_label.text="%d км/ч   •   2.3 т   •   9.81 m/s²\nРуль %+0.1f°   •   RWD"%[int(round(kmh)),rad_to_deg(car.steering)]
    if car.global_position.y < -8.0: _reset_car()

func _process(delta:float) -> void:
    if car==null or camera==null: return
    var cp:=cos(cam_pitch)
    var off:=Vector3(sin(cam_yaw)*cp,sin(cam_pitch),cos(cam_yaw)*cp)*cam_distance
    var target:=car.global_position+Vector3.UP*1.15
    camera.global_position=camera.global_position.lerp(target+off,1.0-exp(-10.0*delta))
    camera.look_at(target,Vector3.UP)

func _input(event:InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed: touch_points[event.index]=event.position
        else: touch_points.erase(event.index)
        if touch_points.size()<2: last_pinch=0.0
    elif event is InputEventScreenDrag:
        touch_points[event.index]=event.position
        if touch_points.size()==1 and event.position.y < 760.0:
            cam_yaw-=event.relative.x*0.006
            cam_pitch=clamp(cam_pitch+event.relative.y*0.005,-0.65,1.20)
        elif touch_points.size()>=2:
            var vals:=touch_points.values(); var d:float=(vals[0] as Vector2).distance_to(vals[1] as Vector2)
            if last_pinch>0.0: cam_distance=clamp(cam_distance-(d-last_pinch)*0.012,4.2,14.0)
            last_pinch=d
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        cam_yaw-=event.relative.x*0.006; cam_pitch=clamp(cam_pitch+event.relative.y*0.005,-0.65,1.20)

func _reset_car() -> void:
    if car==null: return
    var d:Dictionary=stations[station_index]
    left_down=false; right_down=false; gas_down=false; reverse_down=false; handbrake_down=false; steer_value=0.0
    car.freeze=true; car.global_transform=Transform3D(Basis.IDENTITY,d["pos"]); car.linear_velocity=Vector3.ZERO; car.angular_velocity=Vector3.ZERO; car.freeze=false; car.sleeping=false
    station_label.text=str(d["name"])

func _next_station() -> void:
    station_index=(station_index+1)%stations.size(); _reset_car()
